extends "res://UI/ErrorMessage.gd"

const LOG_NAME := "Landie-DeathMessagesPlus:UI/ErrorMessage.gd"

var config = ModLoaderConfig.get_current_config("Landie-DeathMessagesPlus")

var vanilla_msgs = [
    "KilaFlow has bit the dust.",
    "KilaFlow has crashed into a firewall and burned.",
    "KilaFlow has had a fatal encounter.",
    "KilaFlow ran out of batteries.",
    "KilaFlow was cursored to fail.",
    "KilaFlow was just too lazy to finish the virus clearing.",
    "KilaFlow went on strike, demanding a Union.",
    "KilaFlow fell into the recycling bin.",
    "KilaFlow deleted System32 on accident.",
    "KilaFlow tried to kiss the funny dolphin.",
    "KilaFlow befriended a wise gorilla.",
    "KilaFlow extracted a 1TB file.",
    "KilaFlow dipped their tail in digital water.",
    "KilaFlow dropped 9,999,999.999 packets, somehow.",
    "KilaFlow found hot singletons in their area.",
    "KilaFlow downloaded more RAM.",
    "KilaFlow just won a free ChaoPad.",
    "KilaFlow recieved a generous donation from a prince.",
    "KilaFlow let a fancy wooden horse into your system files.",
    "KilaFlow forgot their virus protection and got infected.",
    "KilaFlow angered the task manager.",
    "KilaFlow encountered a skill issue and must cry about it.",
    "KilaFlow made a little oopsie doopsie.",
    "KilaFlow was kill-a-flowed.",
    "KilaFlow got jumpscared.",
    "KilaFlow was patched out.",
    "KilaFlow marked itself as a virus and deleted itself.",
    "KilaFlow pressed the Any key.",
    "KilaFlow is taking a union-mandated break.",
    "KilaFlow decided it was nap time.",
    "KilaFlow clicked outside the 8 tile.",
    "KilaFlow ran out of moves.",
    "KilaFlow tried to open with F2 to F4.",
    "KilaFlow fell for the ol' spicy keychain.",
    "KilaFlow refused to use a switch for their 1000 line IF chain."
]

func change_message():
    var msgs = []
    if config.data.include_vanilla_messages:
        msgs.append_array(vanilla_msgs)
    if config.data.include_custom_messages:
        msgs.append_array(config.data.death_messages)
        
    if msgs.size() == 0:
        msgs.append("FRICK (No messages available, add some!)")
    
    #ModLoaderLog.info(str(msgs), LOG_NAME)
    var rand_msg_i = randi_range(0, msgs.size() - 1)
    death_message = rand_msg_i # i dont know if this variable is used elsewhere so im just setting it incase
    $ErrorText.text = msgs[rand_msg_i]
