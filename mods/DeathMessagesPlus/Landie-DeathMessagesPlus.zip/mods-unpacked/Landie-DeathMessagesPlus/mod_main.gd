extends Node

const MOD_DIR := "Landie-DeathMessagesPlus" # Name of the directory that this file is in
const LOG_NAME := "Landie-DeathMessagesPlus:Main" # Full ID of the mod (AuthorName-ModName)

var mod_dir_path := ""
var extensions_dir_path := ""
var translations_dir_path := ""

func _init() -> void:
    ModLoaderLog.info("Init", LOG_NAME)
    mod_dir_path = ModLoaderMod.get_unpacked_dir().path_join(MOD_DIR)

    # Add extensions
    install_script_extensions()
    install_script_hook_files()

    # Add translations
    add_translations()

func install_script_extensions() -> void:
    extensions_dir_path = mod_dir_path.path_join("extensions")
    ModLoaderMod.install_script_extension(extensions_dir_path.path_join("UI/ErrorMessage.gd"))

func install_script_hook_files() -> void:
    extensions_dir_path = mod_dir_path.path_join("extensions")

func add_translations() -> void:
    translations_dir_path = mod_dir_path.path_join("translations")

func _ready() -> void:
    ModLoaderLog.info("Ready", LOG_NAME)
