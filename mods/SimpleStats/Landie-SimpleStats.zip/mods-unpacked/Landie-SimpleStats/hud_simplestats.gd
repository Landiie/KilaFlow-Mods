extends Control

@onready var kila = get_tree().get_root().get_node("World/Kila")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
    pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
    var stats_str: String = ""
    
    stats_str += "velocity: " + str(kila.velocity) + "\n"
    stats_str += "combo_timer: " + str(kila.get_node("HUD/Combo").combo_timer) + "\n"
    stats_str += "trickbuffer: " + str(kila.trickbuffer) + "\n"
    stats_str += "kilo_buffer: " + str(kila.kilo_buffer) + "\n"
    
    $"Label".text = stats_str
    pass
