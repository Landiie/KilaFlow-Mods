extends "res://UI/hud.gd"

func _ready() -> void: 
    super()
    var simplestats = ModLoader.get_node("Landie-SimpleStats").simplestats_scene.instantiate()
    add_child(simplestats)
    pass
